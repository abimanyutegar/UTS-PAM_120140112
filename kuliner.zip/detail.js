import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';

const FOOD_DATA = [
  {
    id: '1',
    title: 'Nasi Goreng',
    image: require('./images/nasi-goreng.jpg'),
    description: 'Nasi goreng merupakan salah satu kuliner khas Indonesia yang terbuat dari nasi yang digoreng bersama dengan bumbu-bumbu seperti kecap, bawang merah, bawang putih, dan cabai. Biasanya nasi goreng disajikan dengan telur, ayam, atau kerupuk.',
  },
  {
    id: '2',
    title: 'Rendang',
    image: require('./images/rendang.jpg'),
    description: 'Rendang adalah masakan khas Minangkabau yang terbuat dari daging yang dimasak dengan bumbu rempah-rempah seperti cabai, kunyit, jahe, dan serai. Rendang memiliki cita rasa yang kaya dan gurih, dan sering dihidangkan pada acara-acara khusus.',
  },
  {
    id: '3',
    title: 'Sate',
    image: require('./images/sate.jpg'),
    description: 'Sate adalah makanan yang terdiri dari potongan daging yang ditusuk dengan tusuk sate dan kemudian dibakar. Sate biasanya disajikan dengan bumbu kacang atau kecap manis, dan dapat dijumpai di seluruh Indonesia.',
  },
];

const FoodItem = ({ item, onPress }) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <View style={styles.itemContainer}>
        <Image source={item.image} style={styles.itemImage} />
        <Text style={styles.itemTitle}>{item.title}</Text>
      </View>
    </TouchableOpacity>
  );
};

const HomeScreen = ({ navigation }) => {
  const handlePress = (item) => {
    navigation.navigate('Detail', { item });
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={FOOD_DATA}
        renderItem={({ item }) => <FoodItem item={item} onPress={() => handlePress(item)} />}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  listContainer: {
    paddingVertical: 20,
    paddingHorizontal: 10,
  },
  itemContainer: {
    flex: 1,
    margin: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  itemImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    resizeMode: 'cover',
  },
  itemTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
    marginHorizontal: 10,
  },
});

export default HomeScreen;